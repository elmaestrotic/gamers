package com.narvasoft.jugadores;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);
    static ArrayList<Jugadores> gamers = new ArrayList<>();

    public static void main(String[] args) {
        agregarJugador();
        listarJugadores();
      
    }

    static void agregarJugador() {

        char rpta = 'y';

        do {
            System.out.println("Dese adicionar un jugador [y]|[n]: ");
            rpta = sc.next().charAt(0);

            if (rpta == 'y') {
                Jugadores gamer = new Jugadores();
                System.out.println("Digite el nombre para el jugador: ");
                gamer.setNombre(sc.next());

                System.out.println("Digite el nivelpara el jugador: \n"
                        + "'P'principiante, 'I' intermedio, 'A' Avanzado");
                gamer.setNivel(sc.next().charAt(0));
                System.out.println("Digite el Juego favorito para el jugador: ");
                gamer.setJuegofavorito(sc.next());

                gamer.setId((int) (Math.random() * 1000 + 1));
                gamer.setMax_score((int) (Math.random() * 10000 + 1));
                gamers.add(gamer);//adicionamos el jugar
            }
        } while (rpta == 'y');//condición q control el ciclo

    }

    static void eliminarJugador() {

    }

    static void editarJugador() {

    }

    static void mostrarJugador() {

    }

    static void listarJugadores() {
        for (Jugadores jugador : gamers) {
            System.out.println("Jugador: " + jugador.getNombre());
        }

    }

}
